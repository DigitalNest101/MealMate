<?php ;
@session_start()
?>
<?php include 'partials/header.php' ?>
<?php
// echo $_SESSION['status1'];
if (isset($_SESSION['status1'])) {
  // echo $_SESSION['status'];

  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> ' . $_SESSION['status1'] . '
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';

  // echo $_SESSION['status'];
  // unset($_SESSION['status']);
}

// for session timeout
// echo 
// $var = $username;
// if (isset($var)) {
  // echo $username;
  // } else {
//   header("location: welcome.php");
// }
// if(isset($_SESSION['username'])){
//     if(time()-$_SESSION['time'] > 10){
//         session_unset();
//         session_destroy();
//         header("location: login.php");
//     }
// }
?>
<?php include 'partials/nav_hero.php' ?>

<main id="main">

  <!-- ======= About Section ======= -->
  <section id="about" class="about">
    <div class="container" data-aos="fade-up">

      <div class="section-header">
        <h2>About Us</h2>
        <h2>
          <?php 
          $var = $_SESSION['username'];
          $var1 = $_SESSION['password'];
            echo $var ;
            if (isset($var1)) {
              echo "hi";
               } 
              //  else {
                // echo "Bye " + $var;
              //   header("location: welcome.php");
            // } 
          ?>
        </h2>
        <p>Learn More <span>About Us</span></p>
      </div>

      <div class="row gy-4">
        <div class="col-lg-7 position-relative about-img" style="background-image: url(aboutusmeal.jpg); background-repeat: no-repeat;
        background-position-y: -130px;" data-aos="fade-up" data-aos-delay="150">
        </div>
        <div class="col-lg-5 d-flex align-items-center" data-aos="fade-up" data-aos-delay="300">
          <div class="content ps-0 ps-lg-5">
            <p style="font-size:20px;line-height: 30px; ">
              Indulge in the culinary delight at MEAL MATE. We're your go-to destination for
              mouthwatering dishes, prepared with love and delivered to your doorstep. Our mission is to satisfy your
              taste buds with a diverse menu, ensuring every meal is a delightful experience.
              <br><br>
              **What Sets Us Apart:
              <br>
              1.Fresh, high-quality ingredients.<br>
              2.A team of talented chefs.<br>
              3.Prompt and reliable delivery.<br>
              4.A commitment to culinary excellence.
            </p>
          </div>
        </div>
      </div>
    </div>
    </div>
  </section><!-- End About Section -->

  <!-- ======= Why Us Section ======= -->
  <section id="why-us" class="why-us section-bg">
    <div class="container" data-aos="fade-up">

      <div class="row gy-4">

        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
          <div class="why-box">
            <h3>Why Choose Yummy?</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua. Duis aute irure dolor in reprehenderit
              Asperiores dolores sed et. Tenetur quia eos. Autem tempore quibusdam vel necessitatibus optio ad
              corporis.
            </p>
            <div class="text-center">
              <a href="#" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
            </div>
          </div>
        </div>
        <!-- End Why Box -->

        <div class="col-lg-8 d-flex align-items-center">
          <div class="row gy-4">

            <div class="col-xl-4" data-aos="fade-up" data-aos-delay="200">
              <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                <i class="bi bi-clipboard-data"></i>
                <h4>Corporis voluptates officia eiusmod</h4>
                <p>Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip</p>
              </div>
            </div><!-- End Icon Box -->

            <div class="col-xl-4" data-aos="fade-up" data-aos-delay="300">
              <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                <i class="bi bi-gem"></i>
                <h4>Ullamco laboris ladore pan</h4>
                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</p>
              </div>
            </div><!-- End Icon Box -->

            <div class="col-xl-4" data-aos="fade-up" data-aos-delay="400">
              <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                <i class="bi bi-inboxes"></i>
                <h4>Labore consequatur incidid dolore</h4>
                <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere</p>
              </div>
            </div><!-- End Icon Box -->

          </div>
        </div>

      </div>

    </div>
  </section><!-- End Why Us Section -->

  <!-- ======= Menu Section ======= -->
  <section id="menu" class="menu">
    <div class="container" data-aos="fade-up">

      <div class="section-header">
        <p>Check Our</p>
      </div>

      <div class="tab-content" data-aos="fade-up" data-aos-delay="300">

        <div class="tab-pane fade active show" id="menu-starters">

          <div class="tab-header text-center">
            <h3>Ours Plans</h3>
          </div>

          <div class="row gy-5">

            <div class="col-lg-6 menu-item">
              <a href="assets/img/menu/menu-item-1.png" class="glightbox"><img src="assets/img/menu/menu-item-1.png"
                  class="menu-img img-fluid" alt=""></a>
              <!-- <h4>Delux</h4> -->
              <!-- <div class="col-md-5 col-lg-6"> -->
              <div class="item">
                <div class="heading">
                  <h3>Deluxe</h3>
                </div>
                <!-- <p>Limited Meal</p> -->
                <div class="features">
                  <h4><span class="feature">Food</span> : <span class="value">Only Veg</span></h4>
                  <h4><span class="feature">Limited</span> : <span class="value">Bread, Sweets,<br />curry</span></h4>
                  <h4><span class="feature">Duration</span> : <span class="value">30 Days</span></h4>
                </div>
                <div class="price">
                  4,000
                </div>
                <button class="btn btn-block btn-outline-primary h-75" type="submit">Subscription</button>
              </div>
              <!-- </div> -->

            </div><!-- Menu Item -->

            <div class="col-lg-6 menu-item">
              <a href="assets/img/menu/menu-item-1.png" class="glightbox"><img src="assets/img/menu/menu-item-1.png"
                  class="menu-img img-fluid" alt=""></a>
              <!-- <h4>Delux</h4> -->
              <!-- <div class="col-md-5 col-lg-6"> -->
              <div class="item">
                <div class="heading">
                  <h3>Premium</h3>
                </div>
                <!-- <p>Limited Meal</p> -->
                <div class="features">
                  <h4><span class="feature mb-lg-4 ">Food</span> : <span class="value"> Veg & Non-Veg </span></h4>
                  <h4><span class="feature">Unlimited</span> : <span class="value">Bread, Sweets,<br />curry</span></h4>
                  <h4><span class="feature">Duration</span> : <span class="value">30 Days</span></h4>
                </div>
                <div class="price">
                  6,500
                </div>
                <button class="btn btn-block btn-outline-primary" type="submit">Subscription</button>
              </div>
              <!-- </div> -->
            </div><!-- Menu Item -->
            <!-- Menu Item -->
          </div>
        </div><!-- End Starter Menu Content -->
        <!-- End Breakfast Menu Content -->
      </div>
    </div>
  </section><!-- End Menu Section -->

  <!-- ======= Registration Begins ======= -->
  <section id="book-a-table" class="book-a-table">
    <div class="container" data-aos="fade-up">

      <div class="section-header">
        <p> <span>Register Yourself</span></p>
      </div>

      <div class="row g-0">

        <div class="col-lg-4 reservation-img" style="background-image: url(assets/img/reservation.jpg);"
          data-aos="zoom-out" data-aos-delay="200"></div>

        <div class="col-lg-8 d-flex align-items-center reservation-form-bg">
          <form action="forms/book-a-table.php" method="post" role="form" class="php-email-form" data-aos="fade-up"
            data-aos-delay="100">
            <div class="row gy-4">
              <div class="col-lg-4 col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name"
                  data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                <div class="validate"></div>
              </div>
              <div class="col-lg-4 col-md-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email"
                  data-rule="email" data-msg="Please enter a valid email">
                <div class="validate"></div>
              </div>
              <div class="col-lg-4 col-md-6">
                <input type="text" class="form-control" name="phone" id="phone" placeholder="Your Phone"
                  data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                <div class="validate"></div>
              </div>
              <div class="col-lg-4 col-md-6">
                <input type="text" name="date" class="form-control" id="date" placeholder="Date" data-rule="minlen:4"
                  data-msg="Please enter at least 4 chars">
                <div class="validate"></div>
              </div>
              <div class="col-lg-4 col-md-6">
                <input type="text" class="form-control" name="time" id="time" placeholder="Time" data-rule="minlen:4"
                  data-msg="Please enter at least 4 chars">
                <div class="validate"></div>
              </div>
              <div class="col-lg-4 col-md-6">
                <input type="number" class="form-control" name="people" id="people" placeholder="# of people"
                  data-rule="minlen:1" data-msg="Please enter at least 1 chars">
                <div class="validate"></div>
              </div>
            </div>
            <div class="form-group mt-3">
              <textarea class="form-control" name="message" rows="5" placeholder="Message"></textarea>
              <div class="validate"></div>
            </div>
            <div class="mb-3">
              <div class="loading">Loading</div>
              <div class="error-message"></div>
              <div class="sent-message">Your booking request was sent. We will call back or send an Email to confirm
                your reservation. Thank you!</div>
            </div>
            <div class="text-center"><button type="submit">Register</button></div>
          </form>
        </div><!-- End Reservation Form -->

      </div>

    </div>
  </section><!-- End Book A Table Section -->

</main><!-- End #main -->

<?php include 'partials/footer.php' ?>