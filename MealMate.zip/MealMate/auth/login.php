<?php
session_start();
$login = false;
$showError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../connection.php';
    $username = $_POST["username"];
    $password = $_POST["password"];
    // $password1 = $_POST["password1"];

    $sql = "select * from users where username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    if ($num == 1) {
        $login = true;
        // session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['time'] = time();
        // $_SESSION['AMAAN'] = $num"";
        header("location: ../index.php");
        $_SESSION['status1'] = "you logged in successfully";
    }
} else {
    $showError = "Invalid crediantials";
}
?>

<?php include '../partials/header.php' ?>
<?php

if ($login) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> Your logged in to a system.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
}

if ($showError) {
    echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
        <strong>Error</strong> ' . $showError . '
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
}

if (isset($_SESSION['status'])) {    
    
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> '.$_SESSION['status'].'
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';     
    // echo $_SESSION['status'];
    unset($_SESSION['status']);
}
?>
<h2 class="text-center ">I am Login Page</h2>
<div class="container">
    <h1 class="text-center">Login your website</h1>
    <form action="../index.php" method="post">
        <div class="form-group col-md-6  mb-3 ">
            <label for="username" class="form-label">Username</label>
            <input type="email" class="form-control" id="username" name="username" aria-describedby="emailHelp">

        </div>
        <div class="mb-3 col-md-6">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password">
            <!-- <p class="error password_error">lorem</p> -->
        </div>

        <div class="mb-3 form-check ">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label><br/>
            <label for="exampleCheck1" class="form-check-label">Dont check me</label>
        </div>
        <button type="submit" class="btn btn-primary col-md-6" name="login-up">Login</button>
    </form>
</div>


