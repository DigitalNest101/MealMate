<?php include '../partials/header.php'; ?>
<?php
session_start();
$showAlert = false;
$showError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../connection.php';
    $username = $_POST["username"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];
    $data = array($username, $password, $cpassword);

    if (($password == $cpassword) && $showAlert == false && !empty($username) && !empty($password)) {
        $sql = "INSERT INTO `users` (`username`, `password`, `dt`) VALUES ('$username','$password', current_timestamp())";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $showAlert = true;
            header("location: login.php");
            $_SESSION['status'] = "data inserted successfully"; 
        }
    } else {
        $showError = "password do not match";
    }
}
?>
<?php
if ($showAlert) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success</strong> Your account is created and u can login now.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
}

if ($showError) {
    // $_SESSION[$showError] = 'sas';        
    echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
        <strong>Error</strong> ' . $showError . '
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>';
}
?>

<h2 class="text-center ">I am sign up page</h2>
<div class="container">
    <h1 class="text-center">Sign up your website</h1>
    <form action="login.php" method="post">
        <div class="form-group col-md-6  mb-3 ">
            <label for="username" class="form-label">Username</label>
            <input type="email" class="form-control" id="username" name="username" aria-describedby="emailHelp"
                required>

        </div>
        <div class="mb-3 col-md-6">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
            <p class="error password_error">lorem</p>
        </div>
        <div class="mb-3 col-md-6">
            <label for="cpassword" class="form-label">confirm password</label>
            <input type="password" class="form-control" id="cpassword" name="cpassword" required>
            <div id="emailHelp" class="form-text">Make sure you type the same password </div>
        </div>
        <div class="mb-3 form-check ">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary col-md-6" name="sign-up">signup</button>
    </form>
</div>

